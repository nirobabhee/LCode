{

"dashboard_banner": {
"builder": true,
"no_selection": false,
"name": "Dashboard Banner",
"element": {
"images": {
"image": {
"size": "1200x100"
}
},
"link": "text",
"modal": true
}
},
}
{{-- //banner-image --}}
@php
    $banners = getContent('dashboard_banner.element');
    $randomBanner = $banners[rand(0, count($banners) - 1)];
@endphp

<div class="banner-container">
    <div class="w-1200 h-90 bg-overlay bg_img" style="background-image: url('{{ getImage('assets/images/frontend/dashboard_banner/' . $randomBanner->data_values->image, '1200x90') }}');">
        <a class="banner-link" href="{{ $randomBanner->data_values->link }}" style="display: inline-block; width: 100%; height: 100%;"></a>
        <span class="close-button" onclick="closeBanner()">X</span>
    </div>
</div>

@push('script')
    <script>
        function closeBanner() {
            const bannerContainer = document.querySelector('.banner-container');
            bannerContainer.style.display = 'none';
            localStorage.setItem('bannerHidden', 'true');
        }
    </script>
@endpush

@push('style')
    <style>
        .bg_img {
            height: 100px !important;
            border-radius: 5px !important;
            border: 1px solid hsl(var(--base)) !important;
        }

        /* styles.css */
        .banner-container {
            position: relative;
            height: 100px;
        }

        .close-button {
            position: absolute;
            top: 0;
            right: 0;
            width: 9px;
            cursor: pointer;
            color: #ff0000;
            padding: 0px 1px;
            background-color: #b4b2b2;
        }

        .close-button:hover {
            background-color: #fff;
        }

        .banner-container .bg-overlay {
            background-color: rgba(0, 0, 0, 0.5);
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
        }
    </style>
@endpush
