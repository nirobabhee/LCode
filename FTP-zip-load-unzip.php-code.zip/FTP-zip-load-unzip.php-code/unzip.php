<?php
$zip = new ZipArchive;
$res = $zip->open('hyiplab_grantmining.zip');

if ($res === TRUE) {
    $zip->extractTo('.');
    $zip->close();
    echo 'Woohoo! Your file was extracted.';
} else {
    echo 'Darn! There was a problem opening the file.';
}
?>