<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if file was uploaded without errors
    if (isset($_FILES["fileToUpload"]) && $_FILES["fileToUpload"]["error"] == 0) {
        $filename = $_FILES["fileToUpload"]["name"];
        $fileTmpName = $_FILES["fileToUpload"]["tmp_name"];
        $fileSize = $_FILES["fileToUpload"]["size"];

        // Specify your FTP server details
        $ftpHost = "ftp.brutalmarkets.com"; // Replace with your FTP server
        $ftpUsername = "u393301445.viserlab"; // Replace with your FTP username
        $ftpPassword = "Viserlab1!"; // Replace with your FTP password

        // Setup connection to FTP server
        $ftpConn = ftp_connect($ftpHost) or die("Could not connect to $ftpHost");
        $login = ftp_login($ftpConn, $ftpUsername, $ftpPassword);

        if (!$login) {
            die('Could not log in to FTP server');
        }

        // Turn passive mode on
        ftp_pasv($ftpConn, true);

        // Upload the file to the FTP server (specify destination directory if necessary)
        $remoteFile = $filename;

        if (ftp_put($ftpConn, $remoteFile, $fileTmpName, FTP_BINARY)) {
            echo "Successfully uploaded $filename.";
        } else {
            echo "Error uploading $filename.";
        }

        // Close FTP connection
        ftp_close($ftpConn);
    } else {
        echo "Error: " . $_FILES["fileToUpload"]["error"];
    }
}
?>
