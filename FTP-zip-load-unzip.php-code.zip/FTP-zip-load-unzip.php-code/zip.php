<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$folderPath = 'core';  // Folder relative to /public_html
$zipFilePath = 'output.zip';  // Output ZIP file path

// Check if the folder exists
if (!is_dir($folderPath)) {
    exit("Directory '$folderPath' does not exist or is not accessible.\n");
}

// Initialize ZipArchive class
$zip = new ZipArchive();
echo "Creating ZIP file at: $zipFilePath<br>";

if ($zip->open($zipFilePath, ZipArchive::CREATE) !== TRUE) {
    
    exit("Cannot open <$zipFilePath>\n");
}

// Function to add folder to zip
function folderToZip($folderPath, $zipFile, $exclusiveLength) {
    // Try to open the directory
    $handle = opendir($folderPath);
    
    if ($handle === false) {
        exit("Failed to open directory: $folderPath\n");
    }

    // Loop through directory contents
    while (FALSE !== $f = readdir($handle)) {
        // Skip . and .. entries
        if ($f != '.' && $f != '..') {
            $filePath = "$folderPath/$f";
            $localPath = substr($filePath, $exclusiveLength);

            if (is_file($filePath)) {
                $zipFile->addFile($filePath, $localPath);
            } elseif (is_dir($filePath)) {
                $zipFile->addEmptyDir($localPath);
                folderToZip($filePath, $zipFile, $exclusiveLength);
            }
        }
    }
    closedir($handle);
}

// Add the folder to the zip
folderToZip($folderPath, $zip, strlen(dirname($folderPath)) + 1);

// Close the ZIP file
$zip->close();
echo "ZIP file created successfully at: $zipFilePath<br>";

// Force download of the ZIP file
if (file_exists($zipFilePath)) {
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="output.zip"');
    header('Content-Length: ' . filesize($zipFilePath));
    readfile($zipFilePath);
    exit;
} else {
    exit("Error: ZIP file does not exist.\n");
}

?>
