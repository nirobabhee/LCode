function can($code)
{
return Role::hasPermission($code);
}