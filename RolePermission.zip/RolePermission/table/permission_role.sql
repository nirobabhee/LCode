-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2023 at 10:42 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `viserlab_hyiplab_3.9`
--

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`id`, `permission_id`, `role_id`) VALUES
(3, 19, 1),
(4, 20, 1),
(5, 24, 1),
(6, 25, 1),
(7, 26, 1),
(9, 17, 2),
(10, 18, 2),
(11, 19, 2),
(12, 20, 2),
(13, 24, 2),
(14, 25, 2),
(15, 26, 2),
(16, 27, 2),
(17, 1, 2),
(18, 10, 2),
(19, 11, 2),
(20, 12, 2),
(21, 13, 2),
(22, 14, 2),
(23, 15, 2),
(24, 16, 2),
(25, 31, 2),
(26, 32, 2),
(27, 33, 2),
(28, 34, 2),
(29, 1, 1),
(37, 23, 1),
(42, 21, 1),
(43, 22, 1),
(44, 125, 1),
(45, 126, 1),
(46, 127, 1),
(47, 128, 1),
(48, 129, 1),
(49, 2, 1),
(50, 3, 1),
(51, 4, 1),
(52, 5, 1),
(53, 16, 1),
(54, 17, 1),
(55, 18, 1),
(56, 27, 1),
(57, 32, 1),
(58, 38, 1),
(59, 79, 1),
(60, 80, 1),
(61, 82, 1),
(62, 130, 1),
(63, 131, 1),
(64, 132, 1),
(65, 133, 1),
(66, 134, 1),
(67, 135, 1),
(68, 136, 1),
(69, 137, 1),
(70, 138, 1),
(71, 139, 1),
(72, 140, 1),
(73, 142, 1),
(74, 143, 1),
(75, 144, 1),
(76, 145, 1),
(77, 146, 1),
(78, 147, 1),
(79, 148, 1),
(80, 169, 1),
(81, 173, 1),
(82, 174, 1),
(83, 179, 1),
(84, 180, 1),
(85, 226, 1),
(86, 28, 1),
(87, 29, 1),
(88, 30, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `permission_role`
--
ALTER TABLE `permission_role`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
