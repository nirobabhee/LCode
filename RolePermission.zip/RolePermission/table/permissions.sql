-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2023 at 10:42 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `viserlab_hyiplab_3.9`
--

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `group` varchar(40) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `group`, `code`) VALUES
(1, 'Dashboard', 'AdminController', 'admin.dashboard'),
(2, 'Notifications', 'AdminController', 'admin.notifications'),
(3, 'Notification Read', 'AdminController', 'admin.notification.read'),
(4, 'Notifications ReadAll', 'AdminController', 'admin.notifications.readAll'),
(5, 'Request Report', 'AdminController', 'admin.request.report'),
(6, 'Request Report Store', 'AdminController', 'admin.request.report.store'),
(7, 'Download Attachment', 'AdminController', 'admin.download.attachment'),
(8, 'Staff Index', 'StaffController', 'admin.staff.index'),
(9, 'Staff Save', 'StaffController', 'admin.staff.save'),
(10, 'Staff Status', 'StaffController', 'admin.staff.status'),
(11, 'Staff Login', 'StaffController', 'admin.staff.login'),
(12, 'Roles Index', 'RolesController', 'admin.roles.index'),
(13, 'Roles Add', 'RolesController', 'admin.roles.add'),
(14, 'Roles Edit', 'RolesController', 'admin.roles.edit'),
(15, 'Roles Save', 'RolesController', 'admin.roles.save'),
(16, 'Referrals Index', 'ReferralController', 'admin.referrals.index'),
(17, 'Referrals Update', 'ReferralController', 'admin.referrals.update'),
(18, 'Referrals Status', 'ReferralController', 'admin.referrals.status'),
(19, 'Bonus Index', 'BonusController', 'admin.bonus.index'),
(20, 'Bonus Store', 'BonusController', 'admin.bonus.store'),
(21, 'Bonus Update', 'BonusController', 'admin.bonus.update'),
(22, 'Bonus Status', 'BonusController', 'admin.bonus.status'),
(23, 'Time Index', 'TimeSettingController', 'admin.time.index'),
(24, 'Time Store', 'TimeSettingController', 'admin.time.store'),
(25, 'Time Update', 'TimeSettingController', 'admin.time.update'),
(26, 'Time Status', 'TimeSettingController', 'admin.time.status'),
(27, 'Plan Index', 'PlanController', 'admin.plan.index'),
(28, 'Plan Store', 'PlanController', 'admin.plan.store'),
(29, 'Plan Update', 'PlanController', 'admin.plan.update'),
(30, 'Plan Status', 'PlanController', 'admin.plan.status'),
(31, 'Plan Invest Cancel', 'PlanController', 'admin.plan.invest.cancel'),
(32, 'Pin Index', 'PinController', 'admin.pin.index'),
(33, 'Pin Store', 'PinController', 'admin.pin.store'),
(34, 'Pin Used', 'PinController', 'admin.pin.used'),
(35, 'Pin Unused', 'PinController', 'admin.pin.unused'),
(36, 'Pin Generate', 'PinController', 'admin.pin.generate'),
(37, 'Pin User', 'PinController', 'admin.pin.user'),
(38, 'Staking Index', 'StakingPoolController', 'admin.staking.index'),
(39, 'Staking Save', 'StakingPoolController', 'admin.staking.save'),
(40, 'Staking Status', 'StakingPoolController', 'admin.staking.status'),
(41, 'Staking Invest', 'StakingPoolController', 'admin.staking.invest'),
(42, 'Pool Index', 'StakingPoolController', 'admin.pool.index'),
(43, 'Pool Save', 'StakingPoolController', 'admin.pool.save'),
(44, 'Pool Status', 'StakingPoolController', 'admin.pool.status'),
(45, 'Pool Dispatch', 'StakingPoolController', 'admin.pool.dispatch'),
(46, 'Pool Invest', 'StakingPoolController', 'admin.pool.invest'),
(47, 'Promotional Tool Index', 'PromotionalToolController', 'admin.promotional.tool.index'),
(48, 'Promotional Tool Store', 'PromotionalToolController', 'admin.promotional.tool.store'),
(49, 'Promotional Tool Update', 'PromotionalToolController', 'admin.promotional.tool.update'),
(50, 'Promotional Tool Remove', 'PromotionalToolController', 'admin.promotional.tool.remove'),
(51, 'Ranking List', 'RankingController', 'admin.ranking.list'),
(52, 'Ranking Store', 'RankingController', 'admin.ranking.store'),
(53, 'Ranking Status', 'RankingController', 'admin.ranking.status'),
(54, 'Users All', 'ManageUsersController', 'admin.users.all'),
(55, 'Users Active', 'ManageUsersController', 'admin.users.active'),
(56, 'Users Banned', 'ManageUsersController', 'admin.users.banned'),
(57, 'Users Email Verified', 'ManageUsersController', 'admin.users.email.verified'),
(58, 'Users Email Unverified', 'ManageUsersController', 'admin.users.email.unverified'),
(59, 'Users Mobile Unverified', 'ManageUsersController', 'admin.users.mobile.unverified'),
(60, 'Users Kyc Unverified', 'ManageUsersController', 'admin.users.kyc.unverified'),
(61, 'Users Kyc Pending', 'ManageUsersController', 'admin.users.kyc.pending'),
(62, 'Users Mobile Verified', 'ManageUsersController', 'admin.users.mobile.verified'),
(63, 'Users With Balance', 'ManageUsersController', 'admin.users.with.balance'),
(64, 'Users Detail', 'ManageUsersController', 'admin.users.detail'),
(65, 'Users Kyc Details', 'ManageUsersController', 'admin.users.kyc.details'),
(66, 'Users Kyc Approve', 'ManageUsersController', 'admin.users.kyc.approve'),
(67, 'Users Kyc Reject', 'ManageUsersController', 'admin.users.kyc.reject'),
(68, 'Users Update', 'ManageUsersController', 'admin.users.update'),
(69, 'Users Add Sub Balance', 'ManageUsersController', 'admin.users.add.sub.balance'),
(70, 'Users Notification Single', 'ManageUsersController', 'admin.users.notification.single'),
(71, 'Users Notification Single', 'ManageUsersController', 'admin.users.notification.single'),
(72, 'Users Login', 'ManageUsersController', 'admin.users.login'),
(73, 'Users Status', 'ManageUsersController', 'admin.users.status'),
(74, 'Users Notification All', 'ManageUsersController', 'admin.users.notification.all'),
(75, 'Users Notification All Send', 'ManageUsersController', 'admin.users.notification.all.send'),
(76, 'Users List', 'ManageUsersController', 'admin.users.list'),
(77, 'Users Notification Log', 'ManageUsersController', 'admin.users.notification.log'),
(78, 'Users Binary Tree', 'ManageUsersController', 'admin.users.binary.tree'),
(79, 'Subscriber Index', 'SubscriberController', 'admin.subscriber.index'),
(80, 'Subscriber Send Email', 'SubscriberController', 'admin.subscriber.send.email'),
(81, 'Subscriber Remove', 'SubscriberController', 'admin.subscriber.remove'),
(82, 'Subscriber Send Email', 'SubscriberController', 'admin.subscriber.send.email'),
(83, 'Gateway Automatic Index', 'AutomaticGatewayController', 'admin.gateway.automatic.index'),
(84, 'Gateway Automatic Edit', 'AutomaticGatewayController', 'admin.gateway.automatic.edit'),
(85, 'Gateway Automatic Update', 'AutomaticGatewayController', 'admin.gateway.automatic.update'),
(86, 'Gateway Automatic Remove', 'AutomaticGatewayController', 'admin.gateway.automatic.remove'),
(87, 'Gateway Automatic Activate', 'AutomaticGatewayController', 'admin.gateway.automatic.activate'),
(88, 'Gateway Automatic Deactivate', 'AutomaticGatewayController', 'admin.gateway.automatic.deactivate'),
(89, 'Gateway Manual Index', 'ManualGatewayController', 'admin.gateway.manual.index'),
(90, 'Gateway Manual Create', 'ManualGatewayController', 'admin.gateway.manual.create'),
(91, 'Gateway Manual Store', 'ManualGatewayController', 'admin.gateway.manual.store'),
(92, 'Gateway Manual Edit', 'ManualGatewayController', 'admin.gateway.manual.edit'),
(93, 'Gateway Manual Update', 'ManualGatewayController', 'admin.gateway.manual.update'),
(94, 'Gateway Manual Activate', 'ManualGatewayController', 'admin.gateway.manual.activate'),
(95, 'Gateway Manual Deactivate', 'ManualGatewayController', 'admin.gateway.manual.deactivate'),
(96, 'Deposit List', 'DepositController', 'admin.deposit.list'),
(97, 'Deposit Pending', 'DepositController', 'admin.deposit.pending'),
(98, 'Deposit Rejected', 'DepositController', 'admin.deposit.rejected'),
(99, 'Deposit Approved', 'DepositController', 'admin.deposit.approved'),
(100, 'Deposit Successful', 'DepositController', 'admin.deposit.successful'),
(101, 'Deposit Initiated', 'DepositController', 'admin.deposit.initiated'),
(102, 'Deposit Details', 'DepositController', 'admin.deposit.details'),
(103, 'Deposit Reject', 'DepositController', 'admin.deposit.reject'),
(104, 'Deposit Approve', 'DepositController', 'admin.deposit.approve'),
(105, 'Withdraw Pending', 'WithdrawalController', 'admin.withdraw.pending'),
(106, 'Withdraw Approved', 'WithdrawalController', 'admin.withdraw.approved'),
(107, 'Withdraw Rejected', 'WithdrawalController', 'admin.withdraw.rejected'),
(108, 'Withdraw Log', 'WithdrawalController', 'admin.withdraw.log'),
(109, 'Withdraw Details', 'WithdrawalController', 'admin.withdraw.details'),
(110, 'Withdraw Approve', 'WithdrawalController', 'admin.withdraw.approve'),
(111, 'Withdraw Reject', 'WithdrawalController', 'admin.withdraw.reject'),
(112, 'Withdraw Method Index', 'WithdrawMethodController', 'admin.withdraw.method.index'),
(113, 'Withdraw Method Create', 'WithdrawMethodController', 'admin.withdraw.method.create'),
(114, 'Withdraw Method Store', 'WithdrawMethodController', 'admin.withdraw.method.store'),
(115, 'Withdraw Method Edit', 'WithdrawMethodController', 'admin.withdraw.method.edit'),
(116, 'Withdraw Method Update', 'WithdrawMethodController', 'admin.withdraw.method.update'),
(117, 'Withdraw Method Status', 'WithdrawMethodController', 'admin.withdraw.method.status'),
(118, 'Report Transaction', 'ReportController', 'admin.report.transaction'),
(119, 'Report Login History', 'ReportController', 'admin.report.login.history'),
(120, 'Report Login IpHistory', 'ReportController', 'admin.report.login.ipHistory'),
(121, 'Report Notification History', 'ReportController', 'admin.report.notification.history'),
(122, 'Report Email Details', 'ReportController', 'admin.report.email.details'),
(123, 'Report Invest History', 'ReportController', 'admin.report.invest.history'),
(124, 'Report Invest Details', 'ReportController', 'admin.report.invest.details'),
(125, 'Invest Report Dashboard', 'InvestReportController', 'admin.invest.report.dashboard'),
(126, 'Invest Report Statistics', 'InvestReportController', 'admin.invest.report.statistics'),
(127, 'Invest Report Statistics Plan', 'InvestReportController', 'admin.invest.report.statistics.plan'),
(128, 'Invest Report Interest', 'InvestReportController', 'admin.invest.report.interest'),
(129, 'Invest Report Interest Chart', 'InvestReportController', 'admin.invest.report.interest.chart'),
(130, 'Ticket Index', 'SupportTicketController', 'admin.ticket.index'),
(131, 'Ticket Pending', 'SupportTicketController', 'admin.ticket.pending'),
(132, 'Ticket Closed', 'SupportTicketController', 'admin.ticket.closed'),
(133, 'Ticket Answered', 'SupportTicketController', 'admin.ticket.answered'),
(134, 'Ticket View', 'SupportTicketController', 'admin.ticket.view'),
(135, 'Ticket Reply', 'SupportTicketController', 'admin.ticket.reply'),
(136, 'Ticket Close', 'SupportTicketController', 'admin.ticket.close'),
(137, 'Ticket Download', 'SupportTicketController', 'admin.ticket.download'),
(138, 'Ticket Delete', 'SupportTicketController', 'admin.ticket.delete'),
(139, 'Language Manage', 'LanguageController', 'admin.language.manage'),
(140, 'Language Manage Store', 'LanguageController', 'admin.language.manage.store'),
(141, 'Language Manage Delete', 'LanguageController', 'admin.language.manage.delete'),
(142, 'Language Manage Update', 'LanguageController', 'admin.language.manage.update'),
(143, 'Language Key', 'LanguageController', 'admin.language.key'),
(144, 'Language Import Lang', 'LanguageController', 'admin.language.import.lang'),
(145, 'Language Store Key', 'LanguageController', 'admin.language.store.key'),
(146, 'Language Delete Key', 'LanguageController', 'admin.language.delete.key'),
(147, 'Language Update Key', 'LanguageController', 'admin.language.update.key'),
(148, 'Language Get Key', 'LanguageController', 'admin.language.get.key'),
(149, 'Setting Index', 'GeneralSettingController', 'admin.setting.index'),
(150, 'Setting Update', 'GeneralSettingController', 'admin.setting.update'),
(151, 'Setting System Configuration', 'GeneralSettingController', 'admin.setting.system.configuration'),
(153, 'Setting Logo Icon', 'GeneralSettingController', 'admin.setting.logo.icon'),
(154, 'Setting Logo Icon', 'GeneralSettingController', 'admin.setting.logo.icon'),
(155, 'Setting Custom Css', 'GeneralSettingController', 'admin.setting.custom.css'),
(157, 'Setting Cookie', 'GeneralSettingController', 'admin.setting.cookie'),
(159, 'Maintenance Mode', 'GeneralSettingController', 'admin.maintenance.mode'),
(161, 'Matching Bonus', 'GeneralSettingController', 'admin.matching.bonus'),
(162, 'Matching Bonus', 'GeneralSettingController', 'admin.matching.bonus'),
(163, 'Setting Holiday', 'GeneralSettingController', 'admin.setting.holiday'),
(164, 'Setting Holiday Submit', 'GeneralSettingController', 'admin.setting.holiday.submit'),
(165, 'Setting Remove', 'GeneralSettingController', 'admin.setting.remove'),
(166, 'Setting Offday', 'GeneralSettingController', 'admin.setting.offday'),
(167, 'Kyc Setting', 'KycController', 'admin.kyc.setting'),
(169, 'Setting Notification Global', 'NotificationController', 'admin.setting.notification.global'),
(170, 'Setting Notification Global Update', 'NotificationController', 'admin.setting.notification.global.update'),
(171, 'Setting Notification Templates', 'NotificationController', 'admin.setting.notification.templates'),
(172, 'Setting Notification Template Edit', 'NotificationController', 'admin.setting.notification.template.edit'),
(173, 'Setting Notification Template Update', 'NotificationController', 'admin.setting.notification.template.update'),
(174, 'Setting Notification Email', 'NotificationController', 'admin.setting.notification.email'),
(176, 'Setting Notification Email Test', 'NotificationController', 'admin.setting.notification.email.test'),
(177, 'Setting Notification Sms', 'NotificationController', 'admin.setting.notification.sms'),
(179, 'Setting Notification Sms Test', 'NotificationController', 'admin.setting.notification.sms.test'),
(180, 'Setting Notification Push', 'NotificationController', 'admin.setting.notification.push'),
(182, 'Extensions Index', 'ExtensionController', 'admin.extensions.index'),
(183, 'Extensions Update', 'ExtensionController', 'admin.extensions.update'),
(184, 'Extensions Status', 'ExtensionController', 'admin.extensions.status'),
(185, 'System Info', 'SystemController', 'admin.system.info'),
(186, 'System Server Info', 'SystemController', 'admin.system.server.info'),
(187, 'System Optimize', 'SystemController', 'admin.system.optimize'),
(188, 'System Optimize Clear', 'SystemController', 'admin.system.optimize.clear'),
(189, 'System Update', 'SystemController', 'admin.system.update'),
(190, 'System Update Upload', 'SystemController', 'admin.system.update.upload'),
(191, 'Cron Index', 'CronConfigurationController', 'admin.cron.index'),
(192, 'Cron Store', 'CronConfigurationController', 'admin.cron.store'),
(193, 'Cron Update', 'CronConfigurationController', 'admin.cron.update'),
(194, 'Cron Delete', 'CronConfigurationController', 'admin.cron.delete'),
(195, 'Cron Schedule', 'CronConfigurationController', 'admin.cron.schedule'),
(196, 'Cron Schedule Store', 'CronConfigurationController', 'admin.cron.schedule.store'),
(197, 'Cron Schedule Status', 'CronConfigurationController', 'admin.cron.schedule.status'),
(198, 'Cron Schedule Pause', 'CronConfigurationController', 'admin.cron.schedule.pause'),
(199, 'Cron Schedule Logs', 'CronConfigurationController', 'admin.cron.schedule.logs'),
(200, 'Cron Schedule Log Resolved', 'CronConfigurationController', 'admin.cron.schedule.log.resolved'),
(201, 'Cron Log Flush', 'CronConfigurationController', 'admin.cron.log.flush'),
(202, 'Seo', 'FrontendController', 'admin.seo'),
(203, 'Frontend Templates', 'FrontendController', 'admin.frontend.templates'),
(204, 'Frontend Templates Active', 'FrontendController', 'admin.frontend.templates.active'),
(205, 'Frontend Templates Upload', 'FrontendController', 'admin.frontend.templates.upload'),
(206, 'Frontend Sections', 'FrontendController', 'admin.frontend.sections'),
(207, 'Frontend Sections Content', 'FrontendController', 'admin.frontend.sections.content'),
(208, 'Frontend Sections Element', 'FrontendController', 'admin.frontend.sections.element'),
(209, 'Frontend Remove', 'FrontendController', 'admin.frontend.remove'),
(210, 'Frontend Import', 'FrontendController', 'admin.frontend.import'),
(211, 'Frontend Manage Pages', 'PageBuilderController', 'admin.frontend.manage.pages'),
(212, 'Frontend Manage Pages Save', 'PageBuilderController', 'admin.frontend.manage.pages.save'),
(213, 'Frontend Manage Pages Update', 'PageBuilderController', 'admin.frontend.manage.pages.update'),
(214, 'Frontend Manage Pages Delete', 'PageBuilderController', 'admin.frontend.manage.pages.delete'),
(215, 'Frontend Manage Section', 'PageBuilderController', 'admin.frontend.manage.section'),
(216, 'Frontend Manage Section Update', 'PageBuilderController', 'admin.frontend.manage.section.update'),
(217, 'Setting System Configuration Update', 'GeneralSettingController', 'admin.setting.system.configuration.update'),
(218, 'Setting Logo Icon Update', 'GeneralSettingController', 'admin.setting.logo.icon.update'),
(219, 'Setting Custom Css Submit', 'GeneralSettingController', 'admin.setting.custom.css.submit'),
(220, 'Setting Cookie Submit', 'GeneralSettingController', 'admin.setting.cookie.submit'),
(221, 'Maintenance Mode Submit', 'GeneralSettingController', 'admin.maintenance.mode.submit'),
(222, 'Matching Bonus Submit', 'GeneralSettingController', 'admin.matching.bonus.submit'),
(223, 'Kyc Setting Submit', 'KycController', 'admin.kyc.setting.submit'),
(224, 'Setting Notification Email Update', 'NotificationController', 'admin.setting.notification.email.update'),
(225, 'Setting Notification Sms Update', 'NotificationController', 'admin.setting.notification.sms.update'),
(226, 'Setting Notification Push Setting', 'NotificationController', 'admin.setting.notification.push.setting'),
(227, 'Users Notification Single Send', 'ManageUsersController', 'admin.users.notification.single.send'),
(228, 'Plan Activity', 'DataEntryReportController', 'admin.data.entry.plan'),
(229, 'Plan Time Setting Activity', 'DataEntryReportController', 'admin.data.entry.time-setting'),
(230, 'Plan Bonus Activity', 'DataEntryReportController', 'admin.data.entry.bonus');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
