-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 26, 2024 at 11:01 AM
-- Server version: 8.0.30
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `viserlab_ratelab_v3.1`
--

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

CREATE TABLE `advertisements` (
  `id` bigint UNSIGNED NOT NULL,
  `type` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb3_unicode_ci NOT NULL,
  `size` text COLLATE utf8mb3_unicode_ci,
  `redirect_url` text COLLATE utf8mb3_unicode_ci,
  `impression` int NOT NULL DEFAULT '0',
  `click` int NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'ENABLE⇾1 , DISABLE→0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

--
-- Dumping data for table `advertisements`
--

INSERT INTO `advertisements` (`id`, `type`, `value`, `size`, `redirect_url`, `impression`, `click`, `status`, `created_at`, `updated_at`) VALUES
(1, 'image', '63538bfd1ae901666419709.png', '728x90', 'https://viserlab.com/products/php-scripts', 23100, 81, 1, '2022-10-22 03:06:15', '2024-12-26 10:53:30'),
(2, 'image', '63538bf590b411666419701.jpg', '728x90', 'https://viserlab.com/products/php-scripts', 23172, 400, 1, '2022-10-22 03:42:21', '2024-12-26 10:53:30'),
(3, 'script', '<div class=\"__add text-center\" data-id=\"13\"><a href=\"https://viserlab.com/products/php-scripts\" target=\"_blank\"> <img src=\"https://script.viserlab.com/ratelab/assets/images/seo/6228bfcf627c11646837711.png\" alt=\"Ads\"></a></div>', '300x600', NULL, 7813, 4, 1, '2022-10-22 03:44:43', '2024-12-26 10:47:41'),
(4, 'image', '63538cbecd0bb1666419902.jpg', '300x600', 'https://viserlab.com/products/php-scripts', 7674, 68, 1, '2022-10-22 03:55:02', '2024-12-26 10:54:30'),
(5, 'image', '63538ccf545841666419919.jpg', '300x600', 'https://viserlab.com/products/php-scripts', 7891, 66, 1, '2022-10-22 03:55:19', '2024-11-13 07:19:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advertisements`
--
ALTER TABLE `advertisements`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advertisements`
--
ALTER TABLE `advertisements`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
