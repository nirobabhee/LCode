// == Advertisement ===
    Route::controller('AdvertisementController')->name('advertisement.')->prefix('advertisement')->group(function () {
        Route::get('all', 'index')->name('index');
        Route::get('create', 'create')->name('create');
        Route::post('store/{id?}', 'store')->name('store');
    });
