function getAdvertisement($size)
{
    $ad = Advertisement::where('status', Status::ENABLE)->where('size', $size)->inRandomOrder()->first();
    if ($ad) {
        if ($ad->type == 'image') {
            $advertise = '<div class="__add text-center" data-id="' . $ad->id . '">
            <a href="' . $ad->redirect_url . '" target="_blank">
            <img src="' . getImage(getFilePath('advertisement') . '/' . @$ad->value, @$ad->size) . '" alt="Ads">
            </a></div>';
        } else {
            $advertise = '<div class="__add" data-id="' . $ad->id . '">' . $ad->value . '</div>';
        }
        $ad->impression += 1;
        $ad->save();
        return $advertise;
    }
    return false;
}